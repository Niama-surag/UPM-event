# UPM-Event — Bug Fixes + Background Feature

## Files & Destinations

| File in ZIP                                    | Destination                                                  |
|------------------------------------------------|--------------------------------------------------------------|
| src/composables/useTutorial.js                 | REPLACE src/composables/useTutorial.js                       |
| src/components/Layouts/DefaultLayout.vue       | REPLACE src/components/Layouts/DefaultLayout.vue             |
| src/components/BackgroundManager.vue           | NEW — src/components/BackgroundManager.vue                   |
| src/stores/settings.js                         | NEW — src/stores/settings.js                                 |
| src/views/AdminDashboard.vue                   | REPLACE src/views/AdminDashboard.vue                         |

---

## Bug 1 Fixed: DefaultLayout compile error

**Root cause**: Orphaned CSS lines from an old version were accidentally appended
after the closing `</style>` tag. The Vue compiler saw a second `</style>` close
tag with no matching open, causing: `[plugin:vite-plugin-vue-inspector] Invalid end tag`.

**Fix**: Clean DefaultLayout.vue with the orphaned lines removed.
Also adds `<BackgroundManager />` at the bottom of the template.

---

## Bug 2 Fixed: Tutorial overlay won't close

**Root cause**: `useTutorial()` returned a plain object `{ isVisible: Ref<boolean>, ... }`.
When passed to a child component via `v-bind="tutorial"`, Vue does NOT auto-unwrap
refs inside plain objects — only inside `reactive()`. So the child received a Ref
object (always truthy) as the `isVisible` prop, making `v-if="isVisible"` permanently true.

**Fix**: Wrap the return value of `useTutorial` in `reactive()`:

```js
// Before (broken):
return { isVisible, currentStep, ... }

// After (fixed):
return reactive({ isVisible, currentStep, ... })
```

With `reactive()`, refs nested inside are automatically unwrapped, so `v-bind="tutorial"`
correctly passes `isVisible` as a boolean.

---

## New Feature: Admin Site Background

### How it works
1. Admin goes to /admin → "Site Settings" tab
2. Uploads an image or video (drag & drop or click)
3. Adjusts opacity (5–80%), blur (0–20px), and overlay toggle
4. Changes save to Firestore `settings/background` document
5. All users see the update **in real-time** (uses `onSnapshot`)

### Firestore collection required
Create collection `settings` with document `background`:

```json
{
  "type": "none",
  "url": "",
  "opacity": 0.15,
  "blur": 0,
  "overlay": true
}
```

You can create this manually in Firebase Console, or it gets created
automatically when the admin uploads their first background.

### Firebase Storage rules — add this rule
```
match /site/{allPaths=**} {
  allow read: if true;
  allow write: if request.auth != null
    && get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
}
```

### File size limits
- Max 50 MB per file
- Images: JPG, PNG, WebP, GIF
- Videos: MP4, WebM (H.264 recommended)

### Tips for best UX
- Keep opacity below 30% so text remains readable
- Use short looping videos (5–15 seconds)
- Landscape images (1920×1080+) for full coverage

---

## Apply Steps

1. Extract ZIP
2. Copy 5 files to their destinations (see table above)
3. Add `settings/background` document to Firestore (or let first upload create it)
4. Add Storage rule for `/site/` path
5. Run: `npm run dev`
6. Login as admin → go to /admin → "Site Settings" tab
