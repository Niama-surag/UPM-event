# UPM-Event — UI/UX Refactor Package

## Files and where to place them

| File in this ZIP                                    | Destination in your project                              |
|-----------------------------------------------------|----------------------------------------------------------|
| src/components/Layouts/DefaultLayout.vue            | Replace existing DefaultLayout.vue                      |
| src/components/MusicPlayer.vue                      | NEW FILE — create this file                             |
| src/stores/music.js                                 | NEW FILE — create this file                             |
| src/views/HomeView.vue                              | Replace existing HomeView.vue                           |
| src/views/ExploreView.vue                           | NEW FILE — create this file (replaces Club + Events)    |
| src/router/index.js                                 | Replace existing index.js                               |

## What changed and WHY

### 1. Nav simplified (DefaultLayout.vue)
BEFORE: Home, About, Étudiant, Club, Chat, Events, Polls, Dashboard, Notifications, Profile, Logout
AFTER:  Home, Explore, Polls, Alerts  + Profile dropdown (avatar menu)

WHY: 11 nav items is too many — causes analysis paralysis on mobile.
     Profile + Étudiant merged into an avatar dropdown.
     Club + Events merged into "Explore".
     Dashboard merged into Home.
     Chat is now always-floating (ChatFloatingButton).

### 2. Home page as dashboard hub (HomeView.vue)
- Shows hero section with real stats (events, clubs, members count)
- Shows personalized dashboard cards (my events, my clubs, my votes) when logged in
- Shows upcoming events grid
- Shows clubs row
- Shows recent notifications when logged in

WHY: The old Dashboard page was nearly empty. Moving this content to Home means
     users immediately see value on landing, without a separate navigation step.

### 3. Explore page — merged Clubs & Events (ExploreView.vue)
- Single page with two tabs: Events | Clubs
- Events: searchable, filterable by club + type, with register button inline
- Clubs: searchable, join button inline, create club form

WHY: Club and Events are tightly related (clubs organize events). Merging them
     reduces context-switching and makes discovery much faster.

### 4. Background music system (MusicPlayer.vue + stores/music.js)
- Global Pinia store holds one Audio instance — never re-created on navigation
- Player sits at the bottom of the screen (sticky bar)
- Expand to: control progress, volume, upload own file, or pick a sample
- A subtle FAB icon appears when no track is loaded

WHY: Audio state must live outside the component tree to persist across routes.
     Using a single Audio instance avoids the "song restarts on navigation" bug.

### 5. Smooth page transitions
Added <Transition name="page"> in DefaultLayout wrapping router-view.
WHY: Page transitions make navigation feel polished and intentional.

## After applying

1. Copy all files to their destinations
2. npm run dev
3. Old /club and /events URLs will automatically redirect to /explore

## Notes
- ChatFloatingButton.vue is NOT changed — it already works well
- EspaceEtudiant.vue fix from the previous package still applies
- auth.js fix from the previous package still applies
